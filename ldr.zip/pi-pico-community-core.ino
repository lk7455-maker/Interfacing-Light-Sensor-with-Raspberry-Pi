#define POT_PIN 28  // SIG connected to GP28 (ADC2)

void setup() {
  Serial1.begin(115200);
  pinMode(LED_BUILTIN, OUTPUT);
  Serial1.println("Potentiometer Ready!");
}

void loop() {
  int potValue = analogRead(POT_PIN); // Reads analog numbers from 0 to 1023

  Serial1.print("Analog Value: ");
  Serial1.println(potValue);

  // Turn on the Pico's onboard LED if turned past halfway
  if (potValue > 512) {
    digitalWrite(LED_BUILTIN, HIGH);
  } else {
    digitalWrite(LED_BUILTIN, LOW);
  }

  delay(200);
}